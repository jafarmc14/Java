// import bumbu-bumbu yang diperlukan
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;

// bisa juga diimpor sekaligus seperti ini:
// import java.sql.*

//kita butuhkan untuk mengambil input dari keyboard
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class java_mysql {
	// Menyiapkan paramter JDBC untuk koneksi ke datbase
    static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost/toko_elektronik";
    static final String USER = "root";
    static final String PASS = "";

    // Menyiapkan objek yang diperlukan untuk mengelola database
    static Connection conn;
    static Statement stmt;
    static ResultSet rs;
    
    static InputStreamReader inputStreamReader = new InputStreamReader(System.in);
    static BufferedReader input = new BufferedReader(inputStreamReader);

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Melakukan koneksi ke database
        // harus dibungkus dalam blok try/catch
        try {
            // register driver yang akan dipakai
            Class.forName(JDBC_DRIVER);
            
            // buat koneksi ke database
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            
            // buat objek statement
            stmt = conn.createStatement();
            
            while (!conn.isClosed()) {
                showMenu();
            }
            
            stmt.close();
            conn.close();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
	}
	
	static void showMenu() {
	    System.out.println("\n========= MENU UTAMA =========");
	    System.out.println("1. Insert Data");
	    System.out.println("2. Show Data");
	    System.out.println("3. Edit Data");
	    System.out.println("4. Delete Data");
	    System.out.println("0. Keluar");
	    System.out.println("");
	    System.out.print("PILIHAN> ");

	    try {
	        int pilihan = Integer.parseInt(input.readLine());

	        switch (pilihan) {
	            case 0:
	                System.exit(0);
	                break;
	            case 1:
	                insertKomponen();
	                break;
	            case 2:
	                showData();
	                break;
	            case 3:
	                updateKomponen();
	                break;
	            case 4:
	                deleteKomponen();
	                break;
	            default:
	                System.out.println("Pilihan salah!");
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}
	
	static void showData() {
	    String sql = "SELECT * FROM komponen";
	    try {
	        rs = stmt.executeQuery(sql);
	        
	        System.out.println("+--------------------------------+");
	        System.out.println("|DATA KOMPONEN DI TOKO ELEKTRONIK|");
	        System.out.println("+--------------------------------+");
	        while (rs.next()) {
	            int idKomponen = rs.getInt("id_komponen");
	            String namaKomponen = rs.getString("nama_komponen");
	            int hargaKomponen = rs.getInt("harga");
	            
	            System.out.println(String.format("%d. %s -- (%d)", idKomponen, namaKomponen, hargaKomponen));
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}
	
	static void insertKomponen() {
	    try {
	        // ambil input dari user
	        System.out.print("Nama komponen: ");
	        String namaKomponen = input.readLine().trim();
	        System.out.print("Harga: ");
	        int hargaKomponen = Integer.parseInt(input.readLine());
	        
	        
	        // query simpan
	        String sql = "INSERT INTO komponen (nama_komponen, harga) VALUE('%s', %d)";
	        sql = String.format(sql, namaKomponen, hargaKomponen);
	        
	        // simpan buku
	        stmt.execute(sql);
	        
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}
	
	static void updateKomponen() {
	    try {  
	        // ambil input dari user
	        System.out.print("ID yang mau diedit: ");
	        int idKomponen = Integer.parseInt(input.readLine());
	        System.out.print("Nama komponen: ");
	        String namaKomponen = input.readLine().trim();
	        System.out.print("Harga: ");
	        int harga = Integer.parseInt(input.readLine());

	        // query update
	        String sql = "UPDATE komponen SET nama_komponen='%s', harga=%d WHERE id_komponen=%d";
	        sql = String.format(sql, namaKomponen, harga, idKomponen);

	        // update data buku
	        stmt.execute(sql);
	        
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}
	
	static void deleteKomponen() {
	    try {
	        
	        // ambil input dari user
	        System.out.print("ID yang mau dihapus: ");
	        int idKomponen = Integer.parseInt(input.readLine());
	        
	        // buat query hapus
	        String sql = String.format("DELETE FROM komponen WHERE id_komponen=%d", idKomponen);
	        // hapus data
	        stmt.execute(sql);
	        
	        System.out.println("Data telah terhapus...");
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}

}
